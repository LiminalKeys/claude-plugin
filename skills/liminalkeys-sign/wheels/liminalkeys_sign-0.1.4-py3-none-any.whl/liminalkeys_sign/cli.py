"""Command-line interface for liminalkeys-sign."""

from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path

from liminalkeys_sign import __version__
from liminalkeys_sign.embed import run_embed
from liminalkeys_sign.mcp_embed import (
    resolve_signature_from_mcp,
    verify_identity_chain_from_mcp,
)
from liminalkeys_sign.mcp_trust import McpTrustError, load_envelope_json, verify_signed_mcp_envelope
from liminalkeys_sign.mcp_trust import McpTrustConfig
from liminalkeys_sign.prepare import DEFAULT_BYTES_RESERVED, run_prepare
from liminalkeys_sign.validate import run_validate
from liminalkeys_sign.verify import SignatureVerificationError


def _path_arg(value: str) -> Path:
    return Path(value).expanduser()


def _cmd_prepare(args: argparse.Namespace) -> int:
    result = run_prepare(
        args.input_pdf,
        args.cert,
        args.work_dir,
        chain_paths=args.chain or [],
        field_name=args.field_name,
        bytes_reserved=args.bytes_reserved,
    )
    print(result.digest_hex)
    print(
        f"signed_attrs: {result.signed_attrs_path}",
        f"digest: {result.digest_path}",
        f"state: {result.state_path}",
        sep="\n",
        file=sys.stderr,
    )
    return 0


def _cmd_embed(args: argparse.Namespace) -> int:
    try:
        if not args.signature and not args.mcp_sign_envelope:
            print("embed requires --signature or --mcp-sign-envelope", file=sys.stderr)
            return 2
        signature_path = args.signature
        if args.mcp_sign_envelope:
            if not args.expected_nonce or not args.mcp_host:
                print(
                    "embed with --mcp-sign-envelope requires --expected-nonce and --mcp-host "
                    "(--mcp-trust-config optional; defaults to bundled production trust + JWKS bootstrap)",
                    file=sys.stderr,
                )
                return 2
            sig_bytes = resolve_signature_from_mcp(
                sign_envelope_path=args.mcp_sign_envelope,
                expected_tool="sign_hash",
                expected_nonce=args.expected_nonce,
                mcp_host=args.mcp_host,
                trust_config=args.mcp_trust_config,
            )
            if args.mcp_chain_envelope:
                verify_identity_chain_from_mcp(
                    chain_envelope_path=args.mcp_chain_envelope,
                    expected_nonce=args.chain_nonce or args.expected_nonce,
                    mcp_host=args.mcp_host,
                    trust_config=args.mcp_trust_config,
                    trust_anchors=args.chain_trust or args.trust or [],
                    leaf_cert=args.cert,
                    chain_pem_paths=args.chain or [],
                )
            tmp = Path(tempfile.gettempdir()) / f"lk-mcp-sig-{args.work_dir.name}.bin"
            tmp.write_bytes(sig_bytes)
            signature_path = tmp
        run_embed(
            args.work_dir,
            args.cert,
            signature_path,
            args.output,
            chain_paths=args.chain or [],
            signed_attrs_path=args.signed_attrs,
            timestamp_response=args.timestamp_response,
            digest_path=args.digest,
        )
    except (SignatureVerificationError, McpTrustError) as exc:
        print(f"embed failed: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError as exc:
        print(f"embed failed: {exc}", file=sys.stderr)
        return 2
    return 0


def _cmd_mcp_verify(args: argparse.Namespace) -> int:
    try:
        trust = McpTrustConfig.load_optional(args.mcp_trust_config)
        envelope = load_envelope_json(args.envelope)
        payload = verify_signed_mcp_envelope(
            envelope,
            expected_tool=args.tool,
            expected_nonce=args.expected_nonce,
            mcp_host=args.mcp_host,
            trust=trust,
            envelope_label=f"{args.tool} MCP envelope",
        )
        if args.output:
            import json

            args.output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print("MCP RESPONSE VERIFIED", file=sys.stderr)
        return 0
    except McpTrustError as exc:
        print(f"mcp-verify failed: {exc}", file=sys.stderr)
        return 2


def _cmd_validate(args: argparse.Namespace) -> int:
    outcome = run_validate(
        args.input_pdf,
        args.trust,
        tsa_trust_pems=args.tsa_trust or [],
        signature_index=args.signature_index,
        allow_untrusted_timestamp=args.allow_untrusted_timestamp,
    )
    if args.report:
        args.report.write_text(outcome.report, encoding="utf-8")
    print(outcome.report)
    print(outcome.summary, file=sys.stderr)
    if outcome.warning:
        print(outcome.warning, file=sys.stderr)
    if outcome.ok:
        if outcome.warning:
            print("VALIDATION PASSED (timestamp trust warning)", file=sys.stderr)
        else:
            print("VALIDATION PASSED", file=sys.stderr)
        return 0
    print("VALIDATION FAILED", file=sys.stderr)
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="liminalkeys-sign",
        description="PAdES helper for Liminal Keys AI agent signing (hash-only, pyHanko).",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    sub = parser.add_subparsers(dest="command", required=True)

    p_prepare = sub.add_parser("prepare", help="Prepare PDF and emit sign_hash digest")
    p_prepare.add_argument("input_pdf", type=_path_arg)
    p_prepare.add_argument("--cert", type=_path_arg, required=True, help="Leaf signing certificate (PEM)")
    p_prepare.add_argument(
        "--work-dir",
        type=_path_arg,
        required=True,
        help="Directory for signed_attrs.der, tbs_digest.bin, state.pkl",
    )
    p_prepare.add_argument(
        "--chain",
        type=_path_arg,
        nargs="*",
        default=[],
        help="Additional chain certificates (PEM)",
    )
    p_prepare.add_argument("--field-name", default="LiminalAgentSig")
    p_prepare.add_argument(
        "--bytes-reserved",
        type=int,
        default=DEFAULT_BYTES_RESERVED,
        help=(
            "CMS signature placeholder size in the prepared PDF "
            f"(default {DEFAULT_BYTES_RESERVED} for PAdES B-T + typical TSA token; override if needed)"
        ),
    )
    p_prepare.set_defaults(func=_cmd_prepare)

    p_embed = sub.add_parser("embed", help="Verify signature and embed CMS (+ optional timestamp)")
    p_embed.add_argument("--work-dir", type=_path_arg, required=True)
    p_embed.add_argument("--cert", type=_path_arg, required=True)
    p_embed.add_argument("--signature", type=_path_arg, required=False)
    p_embed.add_argument(
        "--mcp-sign-envelope",
        type=_path_arg,
        default=None,
        help="Signed MCP sign_hash JSON envelope (mutual auth)",
    )
    p_embed.add_argument("--mcp-chain-envelope", type=_path_arg, default=None)
    p_embed.add_argument("--expected-nonce", default=None)
    p_embed.add_argument("--chain-nonce", default=None)
    p_embed.add_argument(
        "--mcp-host",
        default=None,
        help="HTTPS MCP host (must match trust config allow list)",
    )
    p_embed.add_argument(
        "--mcp-trust-config",
        type=_path_arg,
        default=None,
        help=(
            "JSON trust pins (allowed_hosts + optional keys by kid). "
            "Omit to use bundled production config (host allow list + JWKS from pinned host)."
        ),
    )
    p_embed.add_argument(
        "--chain-trust",
        type=_path_arg,
        nargs="*",
        default=None,
        help="Trust anchor PEMs for chain anchoring with MCP chain envelope",
    )
    p_embed.add_argument(
        "--trust",
        type=_path_arg,
        nargs="*",
        default=None,
        help="Fallback trust anchors when --chain-trust omitted",
    )
    p_embed.add_argument("--output", type=_path_arg, required=True)
    p_embed.add_argument("--chain", type=_path_arg, nargs="*", default=[])
    p_embed.add_argument("--signed-attrs", type=_path_arg, default=None)
    p_embed.add_argument(
        "--timestamp-response",
        type=_path_arg,
        default=None,
        help="DER RFC 3161 TimeStampResp from MCP timestamp tool (PAdES B-T)",
    )
    p_embed.add_argument("--digest", type=_path_arg, default=None)
    p_embed.set_defaults(func=_cmd_embed)

    p_mcp = sub.add_parser("mcp-verify", help="Verify a signed MCP tool response envelope")
    p_mcp.add_argument("--envelope", type=_path_arg, required=True)
    p_mcp.add_argument("--tool", required=True, choices=["sign_hash", "get_certificate_chain", "timestamp"])
    p_mcp.add_argument("--expected-nonce", required=True)
    p_mcp.add_argument("--mcp-host", required=True)
    p_mcp.add_argument(
        "--mcp-trust-config",
        type=_path_arg,
        default=None,
        help="Trust JSON path (default: bundled production config + JWKS bootstrap)",
    )
    p_mcp.add_argument("--output", type=_path_arg, default=None)
    p_mcp.set_defaults(func=_cmd_mcp_verify)

    p_validate = sub.add_parser("validate", help="Mandatory pyHanko validation gate")
    p_validate.add_argument("input_pdf", type=_path_arg)
    p_validate.add_argument(
        "--trust",
        type=_path_arg,
        nargs="+",
        required=True,
        help="Trust anchor PEM(s) for the signer certificate chain (typically leaf or tenant CA)",
    )
    p_validate.add_argument(
        "--tsa-trust",
        type=_path_arg,
        nargs="*",
        default=None,
        help=(
            "Additional trust anchor PEM(s) for RFC 3161 timestamp (TSA) path building. "
            "Required for PAdES B-T when the TSA root (e.g. FreeTSA) is not the same as --trust."
        ),
    )
    p_validate.add_argument(
        "--allow-untrusted-timestamp",
        action="store_true",
        help=(
            "Warning tier: exit 0 when signer/document checks pass but only TSA trust failed. "
            "Default is fail-closed (matches pyHanko INVALID bottom line)."
        ),
    )
    p_validate.add_argument("--report", type=_path_arg, default=None)
    p_validate.add_argument("--signature-index", type=int, default=0)
    p_validate.set_defaults(func=_cmd_validate)

    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    code = args.func(args)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
